// src/components/PublishedJobs.jsx

import React from 'react';

const PublishedJobs = () => {
  return (
    <div>
      <h2>Published Jobs Page</h2>
      <p>This is the Published Jobs page.</p>
    </div>
  );
};

export default PublishedJobs;
