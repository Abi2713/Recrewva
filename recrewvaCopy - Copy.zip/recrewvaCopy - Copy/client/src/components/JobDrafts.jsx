// src/components/JobDrafts.jsx

import React from 'react';

const JobDrafts = () => {
  return (
    <div>
      <h2>Job Drafts Page</h2>
      <p>This is the Job Drafts page.</p>
    </div>
  );
};

export default JobDrafts;
