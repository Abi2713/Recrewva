// src/components/JobCreation.jsx

import React from 'react';

const JobCreation = () => {
  return (
    <div>
      <h2>Job Creation Page</h2>
      <p>This is the Job Creation page.</p>
    </div>
  );
};

export default JobCreation;
